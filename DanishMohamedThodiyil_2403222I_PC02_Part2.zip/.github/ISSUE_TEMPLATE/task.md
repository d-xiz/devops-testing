---
name: Task
about: Track development tasks
title: '[TASK] '
labels: task
assignees: ''
---

## Task Description


## Related Feature
- [ ] CREATE (Student Registration) - Daniella
- [ ] READ (View Rankings) - Dylan
- [ ] UPDATE (Score Management) - Gengyue
- [ ] DELETE (Account Deletion) - Danish
- [ ] Documentation
- [ ] DevOps

## Subtasks
- [ ]
- [ ]
- [ ]

## Files to Modify
-
-

## Assigned To


## Priority
- [ ] High
- [ ] Medium
- [ ] Low

## Additional Notes

